# Gold Dice RL - TP 1

Agente entregado: `agents.GoldDiceAgent`. TD de control off-policy sobre
*afterstates* con Double learning, gamma = 1. Carga sus pesos de
`artifacts/gold_dice_agent.pkl` y juega greedy, sin intervencion manual.

## Correrlo

```python
from agents import GoldDiceAgent
from evaluate_agents import evaluate

print(evaluate(GoldDiceAgent(), n_episodes=1000, seed=0))
```

## Resultado

| Agente | Media (n = 20.000) | % del optimo teorico |
|---|---:|---:|
| Optimo exacto (programacion dinamica, NO compite) | 644.10 | 100 % |
| **GoldDiceAgent** | **527.06** | **82.0 %** |
| SimpleExpectancy (baseline provisto) | 343.40 | 53.5 % |
| RandomLegal (baseline provisto) | 63.03 | 9.8 % |

Verificado en tres bandas de semillas disjuntas: 527.06 (desarrollo, donde se
tomaron todas las decisiones), 526.27 (control) y 525.42 (publica, seed 0). La
diferencia esta dentro del ruido: no hay sobreajuste.

## Archivos

Provistos por la catedra, sin modificar: `config.py`, `env.py`, `renderer.py`,
`run_example.py`, `evaluate_agents.py`.

Propios:

| Archivo | Que hace |
|---|---|
| `agents.py` | `GoldDiceAgent` (entregado) y `PotentialAgent` (control sin aprendizaje) |
| `afterstate.py` | representacion por afterstates, transiciones deterministas, potencial |
| `value_table.py` | tabla de valores: residuo sobre el potencial, interpolacion lineal en el oro, paso por peso |
| `train_double.py` | entrenamiento del agente entregado |
| `train_afterstate.py` | variante de una sola tabla (ablacion de Double) |
| `train_tabular_classic.py` | Q tabular clasico, con perillas para las ablaciones |
| `oracle_dp.py` | solver exacto del MDP. **No es un agente de aprendizaje**: se usa solo para medir y diagnosticar |
| `evaluate.py` | protocolo de evaluacion con intervalos de confianza y bandas de semillas |
| `diagnose.py` | arrepentimiento exacto por turno contra el oraculo |
| `results.py` | genera la tabla del informe |
| `figures.py` | figura del informe |

## Reproducir

```bash
python oracle_dp.py                 # resuelve el juego exacto (~17 s)
python train_double.py              # entrena el agente
python results.py desarrollo 20000  # tabla del informe
python diagnose.py artifacts/gold_dice_agent.pkl
```

El entrenamiento usa un rango de semillas disjunto del de evaluacion.

## Informe

`informe.pdf` (3 paginas) y `apendice.pdf` (detalle del ambiente, tabla completa
de ablaciones y verificacion de sobreajuste).
